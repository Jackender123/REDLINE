<?php
/**
 * Gara Management - trang quản trị (chỉ Admin).
 * Đăng nhập tại ../login.php (form login của trang chủ).
 */
require_once __DIR__ . '/../includes/auth.php';

$staff = current_staff();
if (!$staff) {
    header('Location: ../login.php');
    exit;
}

$count = static fn(string $sql): int => (int) db()->query($sql)->fetchColumn();
$stats = [
    'Customers'        => $count('SELECT COUNT(*) FROM customers WHERE is_active = 1'),
    'Vehicles'         => $count('SELECT COUNT(*) FROM vehicles WHERE is_active = 1'),
    'Open repair orders' => $count("SELECT COUNT(*) FROM repair_orders WHERE status NOT IN ('completed','delivered')"),
    'Unpaid invoices'  => $count("SELECT COUNT(*) FROM invoices WHERE payment_status = 'unpaid'"),
];

$orders = db()->query(
    'SELECT ro.order_code, ro.status, ro.created_at, v.license_plate, c.full_name AS customer
     FROM repair_orders ro
     JOIN vehicles v ON v.id = ro.vehicle_id
     JOIN customers c ON c.id = v.customer_id
     ORDER BY ro.id DESC LIMIT 10'
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gara Management - Redline</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../login.css?v=<?php echo filemtime(__DIR__ . '/../login.css'); ?>">
</head>
<body>

<header class="portal-header">
    <a href="../index.php" class="login-logo"><span class="logo-slashes">///</span>REDLINE</a>
    <div class="portal-user">
        <span><?php echo e($staff['email']); ?> &middot; <?php echo e($staff['role_name']); ?></span>
        <form method="post" action="../logout.php">
            <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
            <button type="submit" class="show-toggle" style="margin:0">Sign out</button>
        </form>
    </div>
</header>

<main class="portal-main">
    <p class="panel-eyebrow">Gara management</p>
    <h1>Hello, <?php echo e(explode(' ', $staff['full_name'])[0]); ?>.</h1>

    <section class="portal-section">
        <h2>Overview</h2>
        <table class="portal-table">
            <thead><tr><?php foreach ($stats as $label => $_): ?><th><?php echo e($label); ?></th><?php endforeach; ?></tr></thead>
            <tbody><tr><?php foreach ($stats as $n): ?><td><?php echo $n; ?></td><?php endforeach; ?></tr></tbody>
        </table>
    </section>

    <section class="portal-section">
        <h2>Latest repair orders</h2>
        <?php if ($orders): ?>
            <table class="portal-table">
                <thead><tr><th>Code</th><th>Customer</th><th>Plate</th><th>Status</th><th>Received</th></tr></thead>
                <tbody>
                <?php foreach ($orders as $o): ?>
                    <tr>
                        <td><?php echo e($o['order_code']); ?></td>
                        <td><?php echo e($o['customer']); ?></td>
                        <td><?php echo e($o['license_plate']); ?></td>
                        <td><span class="status-pill is-active"><?php echo e($o['status']); ?></span></td>
                        <td><?php echo e($o['created_at']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="portal-empty">No repair orders yet.</p>
        <?php endif; ?>
    </section>
</main>

</body>
</html>
